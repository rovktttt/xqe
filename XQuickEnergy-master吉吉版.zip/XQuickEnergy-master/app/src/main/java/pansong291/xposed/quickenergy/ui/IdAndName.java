package pansong291.xposed.quickenergy.ui;

public class IdAndName  {
    public String name;
    public String id;
}
